import React from "react";

const Fourth = () => {
    return(
        <div className="group-8">
        <div className="background-2"></div>
        <div className="apple-watch">
          <img className="place-your-screen1" src="src/Components/images/place_your_screen1.jpg" alt="" width="210" height="263" />
        </div>
        <div className="text-22">
          <p className="text-23">
            <span className="text-style-2">Lorem ipsum &nbsp;sit</span>
            <br />
            <span className="text-style">&nbsp;</span>
            <br />
            <span className="text-style-3">Ut enim ad minim veniam, quisostrud exercitation ullacboris nit </span>
            <span className="text-style">aliquiminim veniam, quis nostrud exer tation ullamco laboris nisi ut aliqui</span>
          </p>
          <p className="text-24">We Are<br />Creative</p>
        </div>
      </div>
    )
}
export default Fourth