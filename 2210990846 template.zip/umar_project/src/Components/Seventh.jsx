import React from "react";

const Seventh = () => {
    return(
        <div className="group-16">
  <div className="l-constrained-3">
    <p className="text-48">Designed By PSDFreebies.com</p>
    <p className="text-49">COPYRIGHT 2017</p>
  </div>
</div>
    )
}
export default Seventh