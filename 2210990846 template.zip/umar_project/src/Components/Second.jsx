import React from "react";

const Second = () => {
  return (
    <div className="background-image">
      <div className="copy">
        <p className="text-3">We Are Creative Agency</p>
        <p className="text-4">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
          eiusmod tempor incididunt ut labore et Lorem ipsum dolor sit amet,
          consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
          labore et
        </p>
        <div className="rectangle-6-copy-7-holder">
          <a href=""><img
            className="text-5"
            src="src/Components/images/click_here.png"
            alt="Click here"
            width="110"
            height="15"
            title="Click here"
          /></a>
        </div>
      </div>
    </div>
  );
};

export default Second;
