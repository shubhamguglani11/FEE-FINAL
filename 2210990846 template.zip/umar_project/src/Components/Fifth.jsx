import React from "react";

const Fifth = () => {
    return(
        <div className="l-constrained-2">
  <div className="group-9">
    <div className="rectangle-1-copy-2-holder">
      <div className="text-25">
        <p className="text-26">We Are<br />Creative Agency</p>
        <p className="text-27">
          <span className="text-style-2">Lorem ipsum dolor sit</span>
          <br />
          <span className="text-style">&nbsp;</span>
          <br />
          <span className="text-style-3">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut </span>
          <span className="text-style">aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui</span>
        </p>
        <p className="text-28">
          <span className="text-style-2">Lorem ipsum dolor sit</span>
          <br />
          <span className="text-style">&nbsp;</span>
          <br />
          <span className="text-style-3">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut </span>
          <span className="text-style">aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui</span>
        </p>
        <p className="text-29">
          <span className="text-style-2">Lorem ipsum dolor sit</span>
          <br />
          <span className="text-style">&nbsp;</span>
          <br />
          <span className="text-style-3">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut </span>
          <span className="text-style">aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui</span>
        </p>
      </div>
    </div>
    <div className="iphone">
      <img className="place-your-screen-2" src="src/Components/images/place_your_screen.png" alt="" width="270" height="488" />
    </div>
  </div>
  <div className="group-10 group">
    <div className="articles match-height group">
      <div className="col-3">
        <div className="group-11">
          <img className="rectangle-2" src="src/Components/images/rectangle_2.jpg" alt="" />
          <p className="text-30">
            <span className="text-style-4">Lorem ipsum dolor sit</span>
            <br />
            <span className="text-style-5">Ut enim ad minim veniam,quis </span>nostrud exercitation ullamco laboris nisi ut aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui
          </p>
        </div>
        <div className="group-12">
          <img className="rectangle-2-copy-2" src="src/Components/images/rectangle_2_copy_2_2.jpg" alt="" />
          <p className="text-31">
            <span className="text-style-4">Lorem ipsum dolor sit</span>
            <br />
            <span className="text-style-5">Ut enim ad minim veniam,quis </span>nostrud exercitation ullamco laboris nisi ut aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui
          </p>
        </div>
      </div>
      <div className="col-4">
        <div className="group-13">
          <img className="rectangle-2-copy" src="src/Components/images/rectangle_2_copy.jpg" alt="" />
          <p className="text-32">
            <span className="text-style-4">Lorem ipsum dolor sit</span>
            <br />
            <span className="text-style-5">Ut enim ad minim veniam,quis </span>nostrud exercitation ullamco laboris nisi ut aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui
          </p>
        </div>
        <div className="group-14">
          <img className="rectangle-2-copy-2-2" src="src/Components/images/rectangle_2_copy_2.jpg" alt="" />
          <p className="text-33">
            <span className="text-style-4">Lorem ipsum dolor sit</span>
            <br />
            <span className="text-style-5">Ut enim ad minim veniam,quis </span>nostrud exercitation ullamco laboris nisi ut aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui
          </p>
        </div>
      </div>
    </div>
    <div className="rectangle-1-copy-6-holder">
      <div className="side-text">
        <p className="text-34">We Are<br />Creative<br />Agency</p>
        <p className="text-35">
          <span className="text-style-6">Lorem ipsum dolor sit</span>
          <br />
          <span className="text-style">&nbsp;</span>
          <br />
          <span className="text-style-7">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi </span>
          <span className="text-style">ut aliquiminim veniam, quis nostrud exercitation ullamco laboris nisi ut aliqui</span>
        </p>
        <div className="rectangle-6-copy-6-holder">
        <a href=""><img
            className="text-5"
            src="src/Components/images/click_here.png"
            alt="Click here"
            width="110"
            height="15"
            title="Click here"
          /></a>
                  </div>
      </div>
    </div>
  </div>
</div>
    )
}
export default Fifth